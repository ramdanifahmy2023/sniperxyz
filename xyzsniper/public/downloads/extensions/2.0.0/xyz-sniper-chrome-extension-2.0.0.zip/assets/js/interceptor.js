(() => {
  if (window.__sniperCollectorV2) return;
  window.__sniperCollectorV2 = true;
  let enabled = false, generation = 0, sequence = 0;
  const LIMIT = 512 * 1024;
  const nativeFetch = window.fetch;
  const headers = value => { try { return Object.fromEntries(new Headers(value).entries()); } catch (_) { return {}; } };
  function emit(event) {
    if (!enabled || event.generation !== generation) return;
    const { generation: ignored, ...payload } = event;
    window.postMessage({ source:'XYZ_SNIPER_INTERCEPT', payload:SniperPrivacy.redact(payload) }, '*');
  }
  function base(source, url, method = 'GET') {
    let absolute; try { absolute = new URL(url, location.href).href; } catch (_) { absolute = location.href; }
    return { event_id:`evt_${crypto.randomUUID()}`, sequence_no:++sequence, source_type:source, request_url:absolute, method, occurred_at:Date.now(), generation };
  }
  function decode(bytes, type) {
    if (/^(text\/|application\/(?:json|javascript|xml|graphql|x-www-form-urlencoded|x-ndjson))|\+(?:json|xml)(?:;|$)/i.test(type)) {
      const charset = /charset\s*=\s*["']?([^;"'\s]+)/i.exec(type)?.[1] || 'utf-8';
      let raw; try { raw = new TextDecoder(charset).decode(bytes); } catch (_) { raw = new TextDecoder().decode(bytes); }
      if (/json|graphql/i.test(type)) { try { return { value:JSON.parse(raw), format:'json' }; } catch (_) {} }
      return { value:raw, format:'text' };
    }
    let raw = ''; for (let i=0; i<bytes.length; i+=32768) raw += String.fromCharCode(...bytes.subarray(i,i+32768));
    return {value:{encoding:'base64',data:btoa(raw),mime_type:type||'application/octet-stream'},format:'binary'};
  }
  async function body(value, type = '') {
    if (value == null) return {value:null,format:'empty'};
    if (value instanceof FormData) {
      const entries=[];
      for (const [name,item] of value) entries.push({name, value:SniperPrivacy.sensitive(name) ? '[REDACTED]' : item instanceof Blob ? {name:item.name,type:item.type,size:item.size,body_status:'file_metadata_only'} : item});
      return bounded({value:entries,format:'form-data'});
    }
    if (value instanceof Blob) return {...decode(new Uint8Array(await value.slice(0,LIMIT).arrayBuffer()),value.type||type), truncated:value.size>LIMIT};
    if (value instanceof ArrayBuffer || ArrayBuffer.isView(value)) {
      const bytes = value instanceof ArrayBuffer ? new Uint8Array(value) : new Uint8Array(value.buffer,value.byteOffset,value.byteLength);
      return {...decode(bytes.subarray(0,LIMIT),type),truncated:bytes.length>LIMIT};
    }
    if (value instanceof ReadableStream) return {value:null,format:'stream-unavailable'};
    return bounded({value:value instanceof URLSearchParams ? value.toString() : value,format:'text'});
  }
  function bounded(result) {
    const bytes=new TextEncoder().encode(typeof result.value==='string'?result.value:JSON.stringify(result.value));
    if (bytes.length>LIMIT) return {value:new TextDecoder().decode(bytes.subarray(0,LIMIT)),format:'text',truncated:true};
    return result;
  }
  async function requestBody(input, init, type) {
    if (init && Object.hasOwn(init,'body')) return body(init.body,type);
    if (input instanceof Request && !['GET','HEAD'].includes(input.method)) {
      const clone=input.clone();
      if (/multipart\/form-data/i.test(type)) return {value:null,format:'multipart-unavailable'};
      return readBounded(clone.body,type);
    }
    return {value:null,format:'empty'};
  }
  async function readBounded(stream,type) {
    if (!stream) return {value:null,format:'empty'};
    const reader=stream.getReader(), chunks=[]; let size=0, truncated=false;
    try {
      while (true) {
        const {value,done}=await reader.read(); if(done)break;
        const take=value.subarray(0,Math.max(0,LIMIT-size)); chunks.push(take);size+=take.length;
        if (size>=LIMIT) { truncated=true; void reader.cancel().catch(()=>{}); break; }
      }
    } finally { reader.releaseLock(); }
    const buffer=new Uint8Array(size);let offset=0;for(const chunk of chunks){buffer.set(chunk,offset);offset+=chunk.length;}
    return {...decode(buffer,type),truncated};
  }
  window.fetch = function(input, init) {
    if (!enabled) return nativeFetch.apply(this,arguments);
    const method=String(init?.method || (input instanceof Request ? input.method : 'GET')).toUpperCase();
    const url=input instanceof Request ? input.url : String(input);
    const reqHeaders=headers(init?.headers ?? (input instanceof Request ? input.headers : {}));
    const event=base('fetch',url,method), start=performance.now();
    const requestPromise=requestBody(input,init,reqHeaders['content-type']||'').catch(()=>({value:null,format:'unavailable'}));
    const promise=nativeFetch.apply(this,arguments);
    promise.then(response=>{
      let copy;
      try { copy=response.clone(); } catch (error) { emit({...event,responseBodyFormat:'unavailable',error:error.message}); return; }
      void (async()=>{
        const request=await requestPromise;
        const common={...event,requestHeaders:reqHeaders,requestBody:request.value,requestBodyFormat:request.format,responseHeaders:headers(response.headers),status:response.status,content_type:response.headers.get('content-type')||'',response_url:response.url,duration_ms:Math.round(performance.now()-start),truncated:!!request.truncated};
        if (/text\/event-stream|ndjson/i.test(common.content_type) && copy.body) {
          const reader=copy.body.getReader(); let index=0, size=0;
          try {
            while(enabled && event.generation===generation) {
              const {value,done}=await reader.read();if(done)break;
              const chunk=value.subarray(0,Math.max(0,LIMIT-size));size+=chunk.length;
              emit({...common,event_id:`evt_${crypto.randomUUID()}`,stream_id:event.event_id,chunk_index:index++,responseBody:decode(chunk,common.content_type).value,responseBodyFormat:'stream-chunk',truncated:size>=LIMIT || index>=128});
              if(size>=LIMIT || index>=128) break;
            }
          } finally { void reader.cancel().catch(()=>{}); reader.releaseLock(); }
        } else {
          const result=await readBounded(copy.body,common.content_type);
          emit({...common,responseBody:result.value,responseBodyFormat:result.format,truncated:common.truncated||!!result.truncated});
        }
      })().catch(error=>emit({...event,status:response.status,responseBody:null,responseBodyFormat:'unavailable',error:String(error.message)}));
    },error=>{ void requestPromise.then(request=>emit({...event,requestHeaders:reqHeaders,requestBody:request.value,status:0,responseBodyFormat:'network-error',error:String(error.message)})); }).catch(()=>{});
    return promise;
  };
  const open=XMLHttpRequest.prototype.open, send=XMLHttpRequest.prototype.send, setHeader=XMLHttpRequest.prototype.setRequestHeader;
  const xhrState=new WeakMap();
  XMLHttpRequest.prototype.open=function(method,url,...rest){xhrState.set(this,{method,url,headers:{}});return open.call(this,method,url,...rest);};
  XMLHttpRequest.prototype.setRequestHeader=function(key,value){const state=xhrState.get(this);if(state)state.headers[key]=state.headers[key]?`${state.headers[key]}, ${value}`:value;return setHeader.call(this,key,value);};
  XMLHttpRequest.prototype.send=function(value){
    const state=xhrState.get(this);
    if(enabled && state){
      const event=base('xhr',state.url,String(state.method).toUpperCase()),start=performance.now();
      this.addEventListener('loadend',()=>{
        void (async()=>{
          const responseHeaders={};for(const line of this.getAllResponseHeaders().trim().split(/[\r\n]+/)){const at=line.indexOf(':');if(at>0)responseHeaders[line.slice(0,at).toLowerCase()]=line.slice(at+1).trim();}
          let result;
          try { result=this.responseType==='json'?bounded({value:this.response,format:'json'}):await body(this.responseType && this.responseType!=='text'?this.response:this.responseText,responseHeaders['content-type']); }
          catch(_){result={value:null,format:'unavailable'};}
          const request=await body(value,Object.entries(state.headers).find(([key])=>key.toLowerCase()==='content-type')?.[1]);
          emit({...event,requestHeaders:state.headers,requestBody:request.value,requestBodyFormat:request.format,responseHeaders,responseBody:result.value,responseBodyFormat:result.format,content_type:responseHeaders['content-type'],status:this.status,response_url:this.responseURL,duration_ms:Math.round(performance.now()-start),truncated:!!(request.truncated||result.truncated)});
        })().catch(error=>emit({...event,responseBodyFormat:'unavailable',error:error.message}));
      },{once:true});
    }
    return send.call(this,value);
  };
  for(const [name,source] of [['WebSocket','websocket'],['EventSource','eventsource']]){
    const Native=window[name];if(!Native)continue;
    window[name]=new Proxy(Native,{construct(Target,args,newTarget){
      const instance=Reflect.construct(Target,args,newTarget),streamId=`stream_${crypto.randomUUID()}`;
      instance.addEventListener('message',message=>{if(enabled)void body(message.data,'text/plain').then(result=>emit({...base(source,args[0]),stream_id:streamId,responseBody:result.value,responseBodyFormat:'message',truncated:!!result.truncated}));});
      return instance;
    }});
  }
  window.addEventListener('message',event=>{
    if(event.source!==window || event.data?.source!=='XYZ_SNIPER_CONTROL')return;
    const next=event.data.enabled===true;if(next!==enabled)generation++;enabled=next;
  });
  window.postMessage({source:'XYZ_SNIPER_READY'},'*');
})();
