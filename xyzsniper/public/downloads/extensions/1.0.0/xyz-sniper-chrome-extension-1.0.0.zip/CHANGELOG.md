# Changelog Ekstensi XYZ Sniper

## 1.0.0 - 2026-09-29
- Rilis awal ekstensi Chrome XYZ Sniper untuk Windows dan macOS.
- Menyediakan pemasangan melalui menu ekstensi Chrome dalam mode developer.
